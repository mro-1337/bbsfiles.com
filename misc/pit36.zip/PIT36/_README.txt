                                 The Pit
                               version 3.6

                          Copyright (C) 2004 by
                   Chris Johnson and A.S.S.I.S.T. Inc.



I. INTRODUCTION

This is a revised version of The Pit v3.53.  James Berry (deceased)
is responsible for the lion's share of the coding.  Doug Rhea of
A.S.S.I.S.T. Inc. is responsible for recovering the original source
code.  Chris Johnson has made some changes and additions regarding
registration.



II. WHAT'S NEW

This version of the game functions as a registered version of The Pit
v3.53.  By default, the sysop is listed as "FREE COPY", and the BBS as
"BBSFiles.com".  Please visit BBSFiles.com for information on
personalizing your copy of the game with your own sysop and BBS names.

Note that, although the ANSI and EGA terminals should work with this
version, absolutely no testing has been done to ensure that they do.
The standalone program (pit.exe) was the only focus of this effort.



III. REFERENCES

III.1: A Mersenne Twister implementation:

   Copyright (C) 1997 - 2002, Makoto Matsumoto and Takuji Nishimura,
   All rights reserved.                          

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

     1. Redistributions of source code must retain the above copyright
        notice, this list of conditions and the following disclaimer.

     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.

     3. The names of its contributors may not be used to endorse or promote 
        products derived from this software without specific prior written 
        permission.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT
   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
   TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

