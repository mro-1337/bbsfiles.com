#!/bin/sh

mv sherlock.`uname` sherlock
mv libODoors.so.`uname` libODoors.so.3.2
mv libxpdev.so.`uname` libxpdev.so.3.12
ln -s libODoors.so.3.2 libODoors.so
ln -s libxpdev.so.3.12 libxpdev.so
rm *.FreeBSD *.NetBSD *.OpenBSD *.Linux *.exe *.dll *.bat > /dev/null 2>&1
