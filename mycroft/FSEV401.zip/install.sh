#!/bin/sh

mv market.`uname` market
mv timegen.`uname` timegen
mv libODoors.so.`uname` libODoors.so.3.2
ln -s libODoors.so.3.2 libODoors.so
rm *.FreeBSD *.NetBSD *.OpenBSD *.Linux *.exe *.dll *.bat > /dev/null 2>&1
