#!/bin/sh

mv uboat.`uname` uboat
mv libODoors.so.`uname` libODoors.so.6.2
ln -s libODoors.so.6.2 libODoors.so
rm *.FreeBSD *.NetBSD *.OpenBSD *.Linux *.exe *.dll *.bat > /dev/null 2>&1
